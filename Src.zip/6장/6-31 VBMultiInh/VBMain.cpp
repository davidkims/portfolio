#include  "VBParttime.h"

int main()
{
	Parttime chulsoo("Chulsoo", "ABC Univ.", "DEF Co.");
	chulsoo.print();
	return 0;
}